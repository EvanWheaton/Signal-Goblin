# SIGNAL GOBLIN v8 — DUAL BRAIN ARCHITECTURE
## ESP32-C5 (Display/WiFi Brain) + STM32WB55 (Radio Co-Processor)

═══════════════════════════════════════════════════════════════════
ARCHITECTURE OVERVIEW
═══════════════════════════════════════════════════════════════════

┌─────────────────────────┐   UART    ┌──────────────────────────┐
│      ESP32-C5            │◄─────────►│      STM32WB55            │
│   "DISPLAY BRAIN"         │ 115200bps │   "RADIO BRAIN"            │
│                           │           │                            │
│ - ILI9488 3.5" TFT        │           │ - CC1101 Sub-GHz           │
│ - XPT2046 Touch           │           │ - nRF24L01+ 2.4GHz         │
│ - WiFi 2.4GHz + 5GHz scan │           │ - PN532 NFC (I2C)          │
│ - Menu / UI / Goblins     │           │ - IR TX/RX                 │
│ - WS2812B status LED      │           │ - Onboard BLE 5.0          │
│ - Battery monitor         │           │                            │
└─────────────────────────┘           └──────────────────────────┘

Why split it this way:
- ESP32-C5 has limited GPIO (~27 usable) — display + touch alone use 9 pins
- C5 gives us 5GHz WiFi scanning (impossible on classic ESP32 or STM32)
- STM32WB55 has plenty of GPIO + onboard BLE5 — perfect radio co-processor
- Each chip does what it's best at, UART link keeps them in sync

═══════════════════════════════════════════════════════════════════
ESP32-C5 PIN ASSIGNMENTS (Display Brain)
═══════════════════════════════════════════════════════════════════
TFT_CS     GPIO4
TFT_DC     GPIO5
TFT_RST    GPIO6
TFT_BL     GPIO7
SPI_SCK    GPIO0
SPI_MOSI   GPIO1
SPI_MISO   GPIO2
TOUCH_CS   GPIO3
TOUCH_IRQ  GPIO8
UART_TX    GPIO17  → STM32 PA10 (RX)
UART_RX    GPIO18  ← STM32 PA9  (TX)
RGB_DIN    GPIO9
BATT_ADC   GPIO10  (ADC1 channel)
BOOT       GPIO9 (strap — careful, shared consideration)

NOTE: GPIO 11-17 reserved for internal flash on some C5 modules —
verify against your specific module's datasheet before final layout.

═══════════════════════════════════════════════════════════════════
STM32WB55 PIN ASSIGNMENTS (Radio Brain)
═══════════════════════════════════════════════════════════════════
SPI_SCK    PA5   (shared CC1101 + nRF24)
SPI_MISO   PA6
SPI_MOSI   PA7
CC_CS      PA4
CC_GDO0    PA9   -- wait, conflicts with UART, reassign below
CC_GDO2    PA10  -- conflicts with UART, reassign below

REVISED (UART takes PA9/PA10):
UART_TX    PA9   → ESP32-C5 GPIO18
UART_RX    PA10  ← ESP32-C5 GPIO17
CC_CS      PA4
CC_GDO0    PA8
CC_GDO2    PB0
NRF_CSN    PB1
NRF_CE     PB2
NRF_IRQ    PB3
I2C_SDA    PB9   (PN532)
I2C_SCL    PB8
IR_TX      PA0
IR_RX      PA1
RGB_STATUS PA15  (secondary status LED on radio board, optional)

═══════════════════════════════════════════════════════════════════
UART PROTOCOL — 115200 baud, 8N1
═══════════════════════════════════════════════════════════════════
Simple text-based protocol, newline terminated. Easy to debug with
a serial monitor, low overhead for this data rate.

FORMAT:  <CMD>:<PARAM1>,<PARAM2>,...\n

── COMMANDS: ESP32-C5 → STM32WB55 (requests/config) ──────────────
ENTER:NFC                  Enter NFC scanning mode
ENTER:SUBGHZ                Enter Sub-GHz mode
ENTER:NRF24                 Enter 2.4GHz scanner mode
ENTER:IR                    Enter IR capture mode
ENTER:BLE                   Enter BLE scan mode
ENTER:MENU                  Return to idle/menu (stop all radio activity)
CC_FREQ:<mhz>                Set CC1101 frequency (e.g. CC_FREQ:433.92)
IR_REPLAY                    Replay last captured IR code
NRF_CHANNEL:<0-125>           Manual channel select (optional)

── RESPONSES: STM32WB55 → ESP32-C5 (telemetry/data) ──────────────
READY                         STM32 boot complete, all modules initialized
MOD:<name>,<0|1>               Module ready status (e.g. MOD:NFC,1)
NFC_TAG:<type>,<uidhex>          NFC tag detected
NFC_NONE                       No tag present
RSSI:<dbm>                     CC1101 RSSI reading
SPEC:<b0>,<b1>,...,<b7>          8-value spectrum bars (0-100 each)
NRF_CH:<ch>,<activity 0-255>      Single channel scan result
NRF_SUMMARY:<active>,<peakch>     Summary after full 126ch sweep
IR_CODE:<protocol>,<hex>           IR code captured
BLE_DEV:<rssi>,<name>             BLE device found
BLE_DONE:<count>                 BLE scan complete, found N devices
HEARTBEAT                       Sent every 2s — link alive check

═══════════════════════════════════════════════════════════════════
DISPLAY MENU — 2x3 GRID (unchanged from v7)
═══════════════════════════════════════════════════════════════════
NFC | SUB-GHZ | 2.4GHZ
IR  | WIFI    | BLUETOOTH

NEW: "WIFI" replaces SETTINGS slot — runs on ESP32-C5 natively,
shows both 2.4GHz AND 5GHz networks (5GHz = the whole point of C5!)
Settings moved into a swipe-down panel from the top of the screen.
