/*
 * ╔═══════════════════════════════════════════════════════════════╗
 * ║         SIGNAL GOBLIN v8 — ESP32-C5 "DISPLAY BRAIN"           ║
 * ║              Dual-Brain Architecture — Firmware v1.0          ║
 * ╠═══════════════════════════════════════════════════════════════╣
 * ║  Display:    ILI9488 3.5" SPI TFT (320x480)                  ║
 * ║  Touch:      XPT2046 resistive                                ║
 * ║  WiFi:       2.4GHz + 5GHz scanning (WiFi 6 / 802.11ax)       ║
 * ║  RGB:        WS2812B status LED                               ║
 * ║  Link:       UART to STM32WB55 radio co-processor             ║
 * ╚═══════════════════════════════════════════════════════════════╝
 *
 * BOARD SETUP (Arduino IDE):
 *   Board:  ESP32C5 Dev Module
 *   Core:   esp32 by Espressif (3.0+, C5 support required)
 *
 * REQUIRED LIBRARIES:
 *   TFT_eSPI    (Bodmer) — set driver to ILI9488 in User_Setup.h
 *   FastLED     (Daniel Garcia)
 *   WiFi        (built-in)
 *
 * TFT_eSPI User_Setup.h additions:
 *   #define ILI9488_DRIVER
 *   #define TFT_MOSI  1
 *   #define TFT_SCLK  0
 *   #define TFT_MISO  2
 *   #define TFT_CS    4
 *   #define TFT_DC    5
 *   #define TFT_RST   6
 *   #define TOUCH_CS  3
 *   #define SPI_FREQUENCY      27000000
 *   #define SPI_TOUCH_FREQUENCY 2500000
 *
 * NOTE ON C5 GPIO: verify pin numbers against your specific module —
 * some C5 dev boards reserve different GPIOs for flash/PSRAM.
 */

#include <SPI.h>
#include <TFT_eSPI.h>
#include <FastLED.h>
#include <WiFi.h>

// ─────────────────────────────────────────────────────────────────
//  PIN DEFINITIONS — ESP32-C5
// ─────────────────────────────────────────────────────────────────
#define PIN_RGB        9
#define NUM_LEDS       1
#define PIN_BATT_ADC   10

// UART link to STM32WB55 (use UART1, separate from USB serial)
#define LINK_TX        17
#define LINK_RX        18
#define LINK_BAUD      115200

// ─────────────────────────────────────────────────────────────────
//  DISPLAY DIMENSIONS
// ─────────────────────────────────────────────────────────────────
#define TFT_W   320
#define TFT_H   480

// ─────────────────────────────────────────────────────────────────
//  COLORS (RGB565)
// ─────────────────────────────────────────────────────────────────
#define BLACK         0x0000
#define WHITE         0xFFFF
#define GOBLIN_GREEN  0x07E0
#define GOBLIN_DARK   0x03E0
#define BLOOD_RED     0xF800
#define ORANGE        0xFD20
#define GOLD          0xFEA0
#define PURPLE        0x781F
#define CYAN          0x07FF
#define BAND5G        0x9F1F   // violet-blue for 5GHz
#define DARK_GREY     0x2104
#define MID_GREY      0x4208

// ─────────────────────────────────────────────────────────────────
//  HARDWARE OBJECTS
// ─────────────────────────────────────────────────────────────────
TFT_eSPI  tft;
CRGB      leds[NUM_LEDS];
HardwareSerial Link(1);   // UART1 to STM32

// ─────────────────────────────────────────────────────────────────
//  STATE
// ─────────────────────────────────────────────────────────────────
enum AppState {
  STATE_BOOT, STATE_MENU,
  STATE_NFC, STATE_SUBGHZ, STATE_NRF24,
  STATE_IR, STATE_WIFI, STATE_BLUETOOTH
};
AppState currentState = STATE_BOOT;
uint8_t  menuSelection = 0;
uint32_t animFrame = 0, lastAnimTick = 0, lastHeartbeat = 0, lastBattTick = 0;
float    batteryPct = 100.0f;
bool     radioLinkOK = false;

// Radio brain telemetry (filled in via UART)
bool    modReady[5] = {false,false,false,false,false}; // NFC,CC,NRF,IR,BLE
String  nfcTagType = "None";
String  nfcUID = "";
bool    nfcPresent = false;
float   cc1101RSSI = -120;
int     spectrumBars[8] = {0};
float   cc1101Freqs[] = {315.0, 433.92, 868.3, 915.0};
uint8_t cc1101FreqIdx = 1;
int     nrfActive = 0, nrfPeakCh = 0;
uint8_t nrfChannels[126] = {0};
String  irProtocol = "None";
String  irCodeHex  = "0x0";
bool    irReceived = false;
struct BLEDev { String name; int rssi; };
BLEDev  bleDevices[8];
uint8_t bleCount = 0;

// WiFi scan results (native on C5!)
struct WifiNet { String ssid; int rssi; int channel; bool is5g; };
WifiNet wifiNets[20];
uint8_t wifiCount = 0;
uint32_t lastWifiScan = 0;

// Menu definition
const char* menuLabels[] = { "NFC", "SUB-GHZ", "2.4GHZ", "IR", "WIFI", "BLUETOOTH" };
const uint16_t menuColors[] = { CYAN, ORANGE, GOBLIN_GREEN, BLOOD_RED, BAND5G, PURPLE };
const int MENU_COUNT = 6;

// ═══════════════════════════════════════════════════════════════════
//  SETUP
// ═══════════════════════════════════════════════════════════════════
void setup() {
  Serial.begin(115200);
  Link.begin(LINK_BAUD, SERIAL_8N1, LINK_RX, LINK_TX);

  FastLED.addLeds<WS2812B, PIN_RGB, GRB>(leds, NUM_LEDS);
  FastLED.setBrightness(80);
  leds[0] = CRGB::Blue; FastLED.show();  // booting = blue

  tft.init();
  tft.setRotation(0);
  tft.fillScreen(BLACK);

  playBootAnimation();

  // Wait for STM32 READY signal (with timeout)
  tft.fillScreen(BLACK);
  tft.setTextColor(GOBLIN_GREEN);
  tft.setTextSize(2);
  tft.setCursor(40, 220);
  tft.print(F("LINKING RADIO BRAIN..."));
  uint32_t linkStart = millis();
  while (millis() - linkStart < 5000) {
    if (Link.available()) {
      String line = Link.readStringUntil('\n');
      line.trim();
      if (line == "READY") { radioLinkOK = true; break; }
    }
  }
  tft.fillRect(0, 200, TFT_W, 40, BLACK);
  tft.setCursor(40, 220);
  if (radioLinkOK) {
    tft.setTextColor(GOBLIN_GREEN);
    tft.print(F("RADIO BRAIN: LINKED"));
    leds[0] = CRGB::Green; FastLED.show();
  } else {
    tft.setTextColor(BLOOD_RED);
    tft.print(F("RADIO BRAIN: NO RESPONSE"));
    leds[0] = CRGB::Red; FastLED.show();
  }
  delay(1000);

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  currentState = STATE_MENU;
  drawMenu();
}

// ═══════════════════════════════════════════════════════════════════
//  LOOP
// ═══════════════════════════════════════════════════════════════════
void loop() {
  uint32_t now = millis();

  handleTouch();
  pollLink();

  switch (currentState) {
    case STATE_WIFI: loopWifi(); break;
    default: break;
  }

  if (now - lastAnimTick > 400) {
    animFrame++;
    lastAnimTick = now;
    if (currentState == STATE_MENU) drawMenuGoblinAnim();
    else drawModuleGoblinAnim();
  }

  if (now - lastBattTick > 10000) {
    lastBattTick = now;
    readBattery();
    updateRGBStatus();
  }

  // Watchdog: if radio brain stops sending heartbeats, flag it
  if (radioLinkOK && now - lastHeartbeat > 8000) {
    radioLinkOK = false;
  }
}

// ═══════════════════════════════════════════════════════════════════
//  UART LINK — POLL & PARSE INCOMING FROM STM32
// ═══════════════════════════════════════════════════════════════════
void pollLink() {
  while (Link.available()) {
    String line = Link.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) continue;
    handleLinkMessage(line);
  }
}

void sendCmd(const String &cmd) {
  Link.print(cmd);
  Link.print('\n');
}

void handleLinkMessage(String line) {
  int sep = line.indexOf(':');
  String cmd = sep >= 0 ? line.substring(0, sep) : line;
  String arg = sep >= 0 ? line.substring(sep + 1) : "";

  if (cmd == "HEARTBEAT") {
    lastHeartbeat = millis();
    radioLinkOK = true;
    return;
  }
  if (cmd == "READY") { radioLinkOK = true; return; }

  if (cmd == "MOD") {
    // MOD:<name>,<0|1>
    int c = arg.indexOf(',');
    String name = arg.substring(0, c);
    int val = arg.substring(c+1).toInt();
    if (name == "NFC") modReady[0] = val;
    else if (name == "CC") modReady[1] = val;
    else if (name == "NRF") modReady[2] = val;
    else if (name == "IR") modReady[3] = val;
    else if (name == "BLE") modReady[4] = val;
    return;
  }

  if (cmd == "NFC_TAG") {
    int c = arg.indexOf(',');
    nfcTagType = arg.substring(0, c);
    nfcUID = arg.substring(c+1);
    nfcPresent = true;
    if (currentState == STATE_NFC) drawNFCResult();
    leds[0] = CRGB::Cyan; FastLED.show();
    return;
  }
  if (cmd == "NFC_NONE") {
    if (nfcPresent && currentState == STATE_NFC) {
      nfcPresent = false;
      enterNFC();
    }
    return;
  }

  if (cmd == "RSSI") {
    cc1101RSSI = arg.toFloat();
    if (currentState == STATE_SUBGHZ) drawSubGHzUI();
    return;
  }
  if (cmd == "SPEC") {
    // SPEC:b0,b1,...,b7
    int idx = 0, start = 0;
    for (int i = 0; i <= arg.length(); i++) {
      if (i == arg.length() || arg[i] == ',') {
        if (idx < 8) spectrumBars[idx++] = arg.substring(start, i).toInt();
        start = i+1;
      }
    }
    if (currentState == STATE_SUBGHZ) drawSubGHzUI();
    return;
  }

  if (cmd == "NRF_CH") {
    int c = arg.indexOf(',');
    int ch = arg.substring(0, c).toInt();
    int act = arg.substring(c+1).toInt();
    if (ch >= 0 && ch < 126) nrfChannels[ch] = act;
    if (currentState == STATE_NRF24 && ch == 125) drawNRF24UI();
    return;
  }
  if (cmd == "NRF_SUMMARY") {
    int c = arg.indexOf(',');
    nrfActive = arg.substring(0, c).toInt();
    nrfPeakCh = arg.substring(c+1).toInt();
    if (currentState == STATE_NRF24) drawNRF24UI();
    return;
  }

  if (cmd == "IR_CODE") {
    int c = arg.indexOf(',');
    irProtocol = arg.substring(0, c);
    irCodeHex  = arg.substring(c+1);
    irReceived = true;
    if (currentState == STATE_IR) drawIRUI();
    leds[0] = CRGB::Red; FastLED.show();
    return;
  }

  if (cmd == "BLE_DEV") {
    int c = arg.indexOf(',');
    int rssi = arg.substring(0, c).toInt();
    String name = arg.substring(c+1);
    if (bleCount < 8) {
      bleDevices[bleCount].rssi = rssi;
      bleDevices[bleCount].name = name;
      bleCount++;
    }
    if (currentState == STATE_BLUETOOTH) drawBLEUI();
    return;
  }
  if (cmd == "BLE_DONE") {
    if (currentState == STATE_BLUETOOTH) drawBLEUI();
    return;
  }
}

// ═══════════════════════════════════════════════════════════════════
//  BOOT ANIMATION
// ═══════════════════════════════════════════════════════════════════
void playBootAnimation() {
  tft.fillScreen(BLACK);
  for (int r = 0; r < 80; r += 4) {
    tft.fillCircle(160, 200, r, GOBLIN_DARK);
    tft.fillCircle(160, 200, r > 4 ? r-4 : 0, BLACK);
    delay(14);
  }
  for (int y = 0; y < TFT_H; y += 8) { drawBootGoblin(y); delay(10); }
  drawBootGoblin(TFT_H);
  delay(300);

  tft.setTextColor(GOBLIN_GREEN);
  tft.setTextSize(3);
  tft.setCursor(28, 370);
  tft.print(F("SIGNAL"));
  tft.setCursor(28, 405);
  tft.print(F("GOBLIN"));
  tft.setTextSize(1);
  tft.setTextColor(BAND5G);
  tft.setCursor(28, 445);
  tft.print(F("DUAL-BRAIN  *  2.4G + 5G  *  v8"));
  delay(900);

  for (int y = 0; y < TFT_H; y += 2) {
    tft.drawFastHLine(0, y, TFT_W, BLACK);
    delay(1);
  }
}

void drawBootGoblin(int revealY) {
  int cx = 160, cy = 200;
  tft.fillEllipse(cx, cy, 110, 100, GOBLIN_GREEN);
  tft.fillTriangle(cx-110, cy-20, cx-150, cy-80, cx-70, cy-60, GOBLIN_GREEN);
  tft.fillTriangle(cx+110, cy-20, cx+150, cy-80, cx+70, cy-60, GOBLIN_GREEN);
  tft.fillEllipse(cx-38, cy-25, 22, 18, WHITE);
  tft.fillEllipse(cx+38, cy-25, 22, 18, WHITE);
  tft.fillEllipse(cx-38, cy-25, 14, 12, BAND5G);
  tft.fillEllipse(cx+38, cy-25, 14, 12, BAND5G);
  tft.fillCircle(cx-38, cy-25, 6, BLACK);
  tft.fillCircle(cx+38, cy-25, 6, BLACK);
  tft.fillEllipse(cx, cy+8, 18, 12, GOBLIN_DARK);
  tft.fillCircle(cx-8, cy+12, 5, BLACK);
  tft.fillCircle(cx+8, cy+12, 5, BLACK);
  tft.drawArc(cx, cy+35, 40, 35, 200, 340, GOBLIN_DARK, BLACK);
  for (int t = 0; t < 5; t++) {
    int tx = cx - 32 + t*16;
    tft.fillRect(tx, cy+30, 12, 18, WHITE);
  }
  if (revealY < TFT_H) tft.fillRect(0, revealY, TFT_W, TFT_H - revealY, BLACK);
}

// ═══════════════════════════════════════════════════════════════════
//  MENU
// ═══════════════════════════════════════════════════════════════════
void drawMenu() {
  tft.fillScreen(BLACK);
  tft.fillRect(0, 0, TFT_W, 50, GOBLIN_DARK);
  tft.setTextColor(GOBLIN_GREEN);
  tft.setTextSize(2);
  tft.setCursor(60, 8);  tft.print(F("SIGNAL"));
  tft.setCursor(60, 28); tft.print(F("GOBLIN"));
  drawSmallGoblin(10, 0, GOBLIN_GREEN);
  drawBatteryIcon(255, 10);
  drawLinkIcon(295, 14);

  for (int i = 0; i < MENU_COUNT; i++) {
    int col = i % 2, row = i / 2;
    int x = col * 160 + 8, y = 58 + row * 110;
    drawMenuItem(x, y, menuLabels[i], menuColors[i], i == menuSelection);
  }
  drawMenuGoblinAnim();
}

void drawMenuItem(int x, int y, const char* label, uint16_t color, bool selected) {
  uint16_t bg = selected ? color : DARK_GREY;
  uint16_t border = selected ? WHITE : color;
  tft.fillRoundRect(x, y, 148, 95, 10, bg);
  tft.drawRoundRect(x, y, 148, 95, 10, border);
  if (selected) tft.drawRoundRect(x+2, y+2, 144, 91, 8, WHITE);
  tft.setTextColor(selected ? BLACK : color);
  tft.setTextSize(2);
  int lx = x + (148 - strlen(label)*12) / 2;
  tft.setCursor(lx, y + 38);
  tft.print(label);
  // Tag the WIFI tile with "5G" badge
  if (strcmp(label, "WIFI") == 0) {
    tft.setTextSize(1);
    tft.setTextColor(selected ? BLACK : BAND5G);
    tft.setCursor(x+8, y+8);
    tft.print(F("2.4G+5G"));
  }
}

void drawMenuGoblinAnim() {
  int pose = animFrame % 4;
  int x = 100, y = 390;
  tft.fillRect(0, 388, TFT_W, 92, BLACK);
  int sway = (pose < 2) ? 2 : -2;
  tft.fillEllipse(x+sway, y+30, 28, 38, GOBLIN_GREEN);
  tft.fillEllipse(x+sway, y-8, 22, 20, GOBLIN_GREEN);
  tft.fillTriangle(x+sway-22, y-8, x+sway-32, y-28, x+sway-10, y-20, GOBLIN_GREEN);
  tft.fillTriangle(x+sway+22, y-8, x+sway+32, y-28, x+sway+10, y-20, GOBLIN_GREEN);
  tft.fillCircle(x+sway-8, y-12, 4, BAND5G);
  tft.fillCircle(x+sway+8, y-12, 4, BAND5G);
  tft.fillCircle(x+sway-8, y-12, 2, BLACK);
  tft.fillCircle(x+sway+8, y-12, 2, BLACK);
  if (pose == 0 || pose == 2) {
    tft.drawLine(x+sway-28, y+20, x+sway-50, y+5, GOBLIN_GREEN);
    tft.drawLine(x+sway+28, y+20, x+sway+50, y+35, GOBLIN_GREEN);
  } else {
    tft.drawLine(x+sway-28, y+20, x+sway-50, y+35, GOBLIN_GREEN);
    tft.drawLine(x+sway+28, y+20, x+sway+50, y+5, GOBLIN_GREEN);
  }
  tft.setTextColor(MID_GREY);
  tft.setTextSize(1);
  tft.setCursor(175, 425);
  tft.print(F("TAP MODULE TO ENTER"));
  if (!radioLinkOK) {
    tft.setTextColor(BLOOD_RED);
    tft.setCursor(175, 440);
    tft.print(F("! RADIO BRAIN OFFLINE"));
  }
}

// ═══════════════════════════════════════════════════════════════════
//  MODULE SCREEN HEADER
// ═══════════════════════════════════════════════════════════════════
void drawModuleScreen(const char* title, uint16_t color) {
  tft.fillScreen(BLACK);
  tft.fillRect(0, 0, TFT_W, 45, color);
  tft.setTextColor(BLACK);
  tft.setTextSize(2);
  int tx = (TFT_W - strlen(title)*12) / 2;
  tft.setCursor(tx, 14);
  tft.print(title);
  tft.fillRoundRect(4, 4, 40, 28, 6, BLACK);
  tft.setTextColor(color);
  tft.setCursor(10, 12);
  tft.print(F("<<"));
}

// ═══════════════════════════════════════════════════════════════════
//  NFC MODULE  (data comes from STM32 over UART)
// ═══════════════════════════════════════════════════════════════════
void enterNFC() {
  currentState = STATE_NFC;
  nfcPresent = false;
  drawModuleScreen("NFC READER", CYAN);
  drawNFCGoblin();
  tft.setTextColor(CYAN);
  tft.setTextSize(2);
  tft.setCursor(40, 200);
  tft.print(F("HOLD CARD"));
  tft.setCursor(50, 228);
  tft.print(F("TO SCAN"));
  sendCmd("ENTER:NFC");
}

void drawNFCResult() {
  tft.fillRect(0, 180, TFT_W, 260, BLACK);
  tft.setTextColor(CYAN);
  tft.setTextSize(2);
  tft.setCursor(30, 190);
  tft.print(F("TAG DETECTED!"));
  tft.setCursor(10, 225);
  tft.print(F("TYPE: ")); tft.print(nfcTagType);
  tft.setCursor(10, 255);
  tft.print(F("UID: ")); tft.print(nfcUID);
}

void drawNFCGoblin() {
  int pose = animFrame % 4;
  int gx = 30, gy = 100;
  drawModuleGoblinBase(gx, gy, CYAN);
  tft.fillRect(gx+35, gy+10, 30, 22, WHITE);
  tft.drawRect(gx+35, gy+10, 30, 22, CYAN);
  tft.fillRect(gx+40, gy+16, 20, 10, CYAN);
  if (pose % 2 == 0) {
    tft.drawCircle(gx+50, gy+20, 18+pose*4, CYAN);
    tft.drawCircle(gx+50, gy+20, 28+pose*4, GOBLIN_DARK);
  }
}

// ═══════════════════════════════════════════════════════════════════
//  SUB-GHZ MODULE
// ═══════════════════════════════════════════════════════════════════
void enterSubGHz() {
  currentState = STATE_SUBGHZ;
  drawModuleScreen("SUB-GHZ", ORANGE);
  drawSubGHzUI();
  sendCmd("ENTER:SUBGHZ");
}

void drawSubGHzUI() {
  int pose = animFrame % 4;
  tft.fillRect(0, 50, TFT_W, 340, BLACK);
  tft.setTextColor(ORANGE);
  tft.setTextSize(2);
  tft.setCursor(10, 60);
  tft.print(F("FREQ: ")); tft.print(cc1101Freqs[cc1101FreqIdx]); tft.print(F(" MHz"));
  tft.setCursor(10, 90);
  tft.print(F("RSSI: ")); tft.print((int)cc1101RSSI); tft.print(F(" dBm"));
  int rssiBar = map(constrain((int)cc1101RSSI, -120, -20), -120, -20, 0, 260);
  tft.drawRect(10, 112, 262, 14, ORANGE);
  tft.fillRect(11, 113, rssiBar, 12, ORANGE);

  tft.setTextSize(1);
  tft.setCursor(10, 140);
  tft.print(F("SPECTRUM:"));
  for (int i = 0; i < 8; i++) {
    int bh = map(spectrumBars[i], 0, 100, 0, 80);
    uint16_t bc = (spectrumBars[i] > 60) ? BLOOD_RED : ORANGE;
    tft.fillRect(10+i*38, 230-bh, 30, bh, bc);
    tft.drawRect(10+i*38, 150, 30, 80, DARK_GREY);
  }

  for (int i = 0; i < 4; i++) {
    uint16_t bc = (i == cc1101FreqIdx) ? ORANGE : DARK_GREY;
    tft.fillRoundRect(10+i*76, 250, 68, 30, 5, bc);
    tft.setTextColor(i == cc1101FreqIdx ? BLACK : ORANGE);
    tft.setTextSize(1);
    tft.setCursor(14+i*76, 262);
    tft.print(cc1101Freqs[i]);
  }
  drawSubGHzGoblin(220, 55, pose);
}

void drawSubGHzGoblin(int gx, int gy, int pose) {
  drawModuleGoblinBase(gx, gy, ORANGE);
  int antLen = 30 + (pose % 2) * 15;
  tft.drawLine(gx+25, gy-10, gx+25, gy-10-antLen, GOLD);
  tft.fillRect(gx+22, gy-10-antLen, 6, 4, GOLD);
  for (int w = 0; w < 3; w++) {
    int wr = 10 + w*8 + (pose%3)*3;
    tft.drawArc(gx+25, gy-10-antLen, wr, wr-2, 300, 60, ORANGE, BLACK);
  }
}

// ═══════════════════════════════════════════════════════════════════
//  nRF24 MODULE
// ═══════════════════════════════════════════════════════════════════
void enterNRF24() {
  currentState = STATE_NRF24;
  memset(nrfChannels, 0, sizeof(nrfChannels));
  drawModuleScreen("2.4GHz SCAN", GOBLIN_GREEN);
  drawNRF24UI();
  sendCmd("ENTER:NRF24");
}

void drawNRF24UI() {
  tft.fillRect(0, 50, TFT_W, 340, BLACK);
  tft.setTextColor(GOBLIN_GREEN);
  tft.setTextSize(1);
  tft.setCursor(10, 55);
  tft.print(F("2.4GHz CHANNEL SCAN (126CH)"));
  for (int i = 0; i < 126; i++) {
    int bh = map(nrfChannels[i], 0, 255, 0, 100);
    uint16_t col = nrfChannels[i] > 128 ? BLOOD_RED :
                   nrfChannels[i] > 64  ? ORANGE : GOBLIN_GREEN;
    tft.fillRect(i*2+2, 200-bh, 2, bh, col);
  }
  tft.drawFastHLine(2, 200, 252, GOBLIN_DARK);
  tft.setTextColor(GOBLIN_GREEN);
  tft.setTextSize(2);
  tft.setCursor(10, 220); tft.print(F("ACTIVE: ")); tft.print(nrfActive);
  tft.setCursor(10, 248); tft.print(F("PEAK CH: ")); tft.print(nrfPeakCh);
  drawNRF24Goblin(220, 55, animFrame%4);
}

void drawNRF24Goblin(int gx, int gy, int pose) {
  drawModuleGoblinBase(gx, gy, GOBLIN_GREEN);
  int dish = (pose % 2) * 5;
  tft.fillEllipse(gx-25, gy-15+dish, 12, 8, GOBLIN_DARK);
  tft.fillEllipse(gx+25, gy-15-dish, 12, 8, GOBLIN_DARK);
}

// ═══════════════════════════════════════════════════════════════════
//  IR MODULE
// ═══════════════════════════════════════════════════════════════════
void enterIR() {
  currentState = STATE_IR;
  irReceived = false;
  drawModuleScreen("IR CAPTURE", BLOOD_RED);
  drawIRUI();
  sendCmd("ENTER:IR");
}

void drawIRUI() {
  tft.fillRect(0, 50, TFT_W, 340, BLACK);
  tft.setTextColor(BLOOD_RED);
  tft.setTextSize(2);
  tft.setCursor(10, 65);
  tft.print(F("PROTO: ")); tft.print(irProtocol);
  tft.setCursor(10, 95);
  tft.print(F("CODE: ")); tft.print(irCodeHex);

  if (irReceived) {
    tft.fillRoundRect(10, 135, 145, 50, 8, BLOOD_RED);
    tft.fillRoundRect(165, 135, 145, 50, 8, DARK_GREY);
    tft.setTextColor(BLACK);
    tft.setCursor(30, 155);  tft.print(F("REPLAY"));
    tft.setTextColor(BLOOD_RED);
    tft.setCursor(185, 155); tft.print(F("CLEAR"));
  } else {
    tft.setCursor(50, 160); tft.print(F("WAITING FOR"));
    tft.setCursor(60, 188); tft.print(F("IR SIGNAL"));
  }
  drawIRGoblin(220, 60, animFrame%4);
}

void drawIRGoblin(int gx, int gy, int pose) {
  drawModuleGoblinBase(gx, gy, BLOOD_RED);
  tft.fillRect(gx+20, gy+12, 14, 8, GOBLIN_GREEN);
  tft.fillRect(gx+34, gy+10, 5, 4, GOBLIN_GREEN);
  if (pose % 2 == 0) {
    for (int b = 0; b < 3; b++) tft.drawFastHLine(gx+39+b*8, gy+13, 5, BLOOD_RED);
  }
}

// ═══════════════════════════════════════════════════════════════════
//  WIFI MODULE — NATIVE ON ESP32-C5 (2.4GHz + 5GHz!)
// ═══════════════════════════════════════════════════════════════════
void enterWifi() {
  currentState = STATE_WIFI;
  drawModuleScreen("WIFI SCAN", BAND5G);
  tft.setTextColor(BAND5G);
  tft.setTextSize(2);
  tft.setCursor(60, 200);
  tft.print(F("SCANNING..."));
  lastWifiScan = 0; // force immediate scan
}

void loopWifi() {
  uint32_t now = millis();
  if (now - lastWifiScan < 6000) return;
  lastWifiScan = now;

  int n = WiFi.scanNetworks(false, true); // include hidden
  wifiCount = min(n, 20);
  for (int i = 0; i < wifiCount; i++) {
    wifiNets[i].ssid = WiFi.SSID(i);
    wifiNets[i].rssi = WiFi.RSSI(i);
    wifiNets[i].channel = WiFi.channel(i);
    wifiNets[i].is5g = (wifiNets[i].channel > 14);
  }
  WiFi.scanDelete();
  drawWifiUI();
}

void drawWifiUI() {
  tft.fillRect(0, 50, TFT_W, 410, BLACK);
  tft.setTextColor(BAND5G);
  tft.setTextSize(1);
  tft.setCursor(10, 55);
  tft.print(F("NETWORKS FOUND: ")); tft.print(wifiCount);

  int band24 = 0, band5 = 0;
  for (int i = 0; i < wifiCount; i++) if (wifiNets[i].is5g) band5++; else band24++;
  tft.setCursor(180, 55);
  tft.setTextColor(GOBLIN_GREEN);
  tft.print(F("2.4G:")); tft.print(band24);
  tft.setTextColor(BAND5G);
  tft.print(F(" 5G:")); tft.print(band5);

  for (int i = 0; i < wifiCount && i < 18; i++) {
    int y = 70 + i*20;
    uint16_t col = wifiNets[i].is5g ? BAND5G : GOBLIN_GREEN;
    tft.setTextColor(col);
    tft.setCursor(8, y);
    String ssid = wifiNets[i].ssid;
    if (ssid.length() == 0) ssid = "<hidden>";
    if (ssid.length() > 18) ssid = ssid.substring(0,18);
    tft.print(ssid);
    tft.setCursor(190, y);
    tft.print(F("CH")); tft.print(wifiNets[i].channel);
    tft.setCursor(240, y);
    tft.print(wifiNets[i].rssi); tft.print(F("dB"));
    // band tag
    tft.setCursor(290, y);
    tft.print(wifiNets[i].is5g ? F("5G") : F("2G"));
  }
  drawWifiGoblin(220, 460, animFrame%4);
}

void drawWifiGoblin(int gx, int gy, int pose) {
  // small goblin head with antenna picking up both bands
  drawModuleGoblinBase(gx, gy, BAND5G);
  int h1 = 10 + (pose%2)*6;
  int h2 = 10 + ((pose+2)%4)*4;
  tft.drawLine(gx-8, gy-16, gx-8, gy-16-h1, GOBLIN_GREEN);
  tft.drawLine(gx+8, gy-16, gx+8, gy-16-h2, BAND5G);
  tft.fillCircle(gx-8, gy-16-h1, 2, GOBLIN_GREEN);
  tft.fillCircle(gx+8, gy-16-h2, 2, BAND5G);
}

// ═══════════════════════════════════════════════════════════════════
//  BLUETOOTH MODULE (BLE runs on STM32WB55, results via UART)
// ═══════════════════════════════════════════════════════════════════
void enterBluetooth() {
  currentState = STATE_BLUETOOTH;
  bleCount = 0;
  drawModuleScreen("BLUETOOTH", PURPLE);
  tft.setTextColor(PURPLE);
  tft.setTextSize(2);
  tft.setCursor(40, 120);
  tft.print(F("BLE SCANNING..."));
  drawBLEGoblin(220, 55, 0);
  sendCmd("ENTER:BLE");
}

void drawBLEUI() {
  tft.fillRect(0, 50, TFT_W, 340, BLACK);
  tft.setTextColor(PURPLE);
  tft.setTextSize(2);
  tft.setCursor(10, 60);
  tft.print(F("BLE DEVICES: ")); tft.print(bleCount);
  for (int i = 0; i < bleCount && i < 6; i++) {
    tft.setTextSize(1);
    tft.setCursor(10, 90 + i*28);
    tft.print(bleDevices[i].name);
    tft.setCursor(220, 90 + i*28);
    tft.print(bleDevices[i].rssi); tft.print(F("dB"));
  }
}

void drawBLEGoblin(int gx, int gy, int pose) {
  drawModuleGoblinBase(gx, gy, PURPLE);
  tft.drawLine(gx, gy-15, gx+10, gy-25, PURPLE);
  tft.drawLine(gx+10, gy-25, gx+10, gy+5, PURPLE);
  tft.drawLine(gx+10, gy+5, gx, gy-5, PURPLE);
  tft.drawLine(gx, gy-5, gx+10, gy-15, PURPLE);
  if (pose % 2 == 0) {
    tft.drawCircle(gx+5, gy-10, 18, PURPLE);
    tft.drawCircle(gx+5, gy-10, 28, GOBLIN_DARK);
  }
}

// ═══════════════════════════════════════════════════════════════════
//  SHARED GOBLIN BASE
// ═══════════════════════════════════════════════════════════════════
void drawModuleGoblinBase(int gx, int gy, uint16_t color) {
  tft.fillEllipse(gx, gy+35, 20, 28, color);
  tft.fillEllipse(gx, gy, 18, 16, color);
  tft.fillTriangle(gx-18, gy-4, gx-28, gy-20, gx-8, gy-14, color);
  tft.fillTriangle(gx+18, gy-4, gx+28, gy-20, gx+8, gy-14, color);
  tft.fillCircle(gx-6, gy-2, 3, BAND5G);
  tft.fillCircle(gx+6, gy-2, 3, BAND5G);
  tft.fillCircle(gx-6, gy-2, 1, BLACK);
  tft.fillCircle(gx+6, gy-2, 1, BLACK);
  tft.drawLine(gx-6, gy+6, gx-2, gy+9, GOBLIN_DARK);
  tft.drawLine(gx-2, gy+9, gx+2, gy+9, GOBLIN_DARK);
  tft.drawLine(gx+2, gy+9, gx+6, gy+6, GOBLIN_DARK);
}

void drawModuleGoblinAnim() {
  switch (currentState) {
    case STATE_NFC:      drawNFCGoblin();                       break;
    case STATE_SUBGHZ:   drawSubGHzGoblin(220,55,animFrame%4); break;
    case STATE_NRF24:    drawNRF24Goblin(220,55,animFrame%4);  break;
    case STATE_IR:       drawIRGoblin(220,60,animFrame%4);     break;
    case STATE_WIFI:     drawWifiGoblin(220,460,animFrame%4);  break;
    case STATE_BLUETOOTH:drawBLEGoblin(220,55,animFrame%4);    break;
    default: break;
  }
}

void drawSmallGoblin(int x, int y, uint16_t color) {
  tft.fillEllipse(x+18, y+22, 14, 12, color);
  tft.fillTriangle(x+4,y+18, x,y+8, x+10,y+14, color);
  tft.fillTriangle(x+32,y+18, x+36,y+8, x+26,y+14, color);
  tft.fillCircle(x+13,y+20, 2, BLACK);
  tft.fillCircle(x+23,y+20, 2, BLACK);
}

// ═══════════════════════════════════════════════════════════════════
//  TOUCH INPUT
// ═══════════════════════════════════════════════════════════════════
void handleTouch() {
  uint16_t tx, ty;
  if (!tft.getTouch(&tx, &ty)) return;

  if (currentState == STATE_MENU) {
    handleMenuTouch(tx, ty);
  } else {
    if (tx < 50 && ty < 45) { returnToMenu(); return; }
    handleModuleTouch(tx, ty);
  }
  delay(200);
}

void handleMenuTouch(uint16_t tx, uint16_t ty) {
  for (int i = 0; i < MENU_COUNT; i++) {
    int col = i % 2, row = i / 2;
    int x = col * 160 + 8, y = 58 + row * 110;
    if (tx > x && tx < x+148 && ty > y && ty < y+95) {
      menuSelection = i;
      enterModule(i);
      return;
    }
  }
}

void handleModuleTouch(uint16_t tx, uint16_t ty) {
  if (currentState == STATE_IR && irReceived) {
    if (tx > 10 && tx < 155 && ty > 135 && ty < 185) sendCmd("IR_REPLAY");
    if (tx > 165 && tx < 310 && ty > 135 && ty < 185) {
      irReceived = false; irCodeHex = "0x0"; drawIRUI();
    }
  }
  if (currentState == STATE_SUBGHZ) {
    for (int i = 0; i < 4; i++) {
      if (tx > 10+i*76 && tx < 78+i*76 && ty > 250 && ty < 280) {
        cc1101FreqIdx = i;
        sendCmd("CC_FREQ:" + String(cc1101Freqs[i], 2));
        drawSubGHzUI();
      }
    }
  }
}

void enterModule(int idx) {
  switch (idx) {
    case 0: enterNFC();       break;
    case 1: enterSubGHz();    break;
    case 2: enterNRF24();     break;
    case 3: enterIR();        break;
    case 4: enterWifi();      break;
    case 5: enterBluetooth(); break;
  }
}

void returnToMenu() {
  if (currentState == STATE_NRF24 || currentState == STATE_SUBGHZ ||
      currentState == STATE_NFC   || currentState == STATE_IR ||
      currentState == STATE_BLUETOOTH) {
    sendCmd("ENTER:MENU");
  }
  if (currentState == STATE_WIFI) WiFi.scanDelete();
  currentState = STATE_MENU;
  leds[0] = CRGB::Green; FastLED.show();
  drawMenu();
}

// ═══════════════════════════════════════════════════════════════════
//  BATTERY & STATUS
// ═══════════════════════════════════════════════════════════════════
void readBattery() {
  int raw = analogRead(PIN_BATT_ADC);
  float vadc = (raw / 4095.0f) * 3.3f;
  float vbatt = vadc * 2.0f;
  batteryPct = constrain((vbatt - 3.2f) / (4.2f - 3.2f) * 100.0f, 0.0f, 100.0f);
}

void drawBatteryIcon(int x, int y) {
  int bw = (int)(batteryPct * 36 / 100);
  uint16_t bc = batteryPct > 50 ? GOBLIN_GREEN :
                batteryPct > 20 ? ORANGE : BLOOD_RED;
  tft.drawRect(x, y, 38, 16, GOLD);
  tft.fillRect(x+38, y+4, 4, 8, GOLD);
  tft.fillRect(x+1, y+1, bw, 14, bc);
}

void drawLinkIcon(int x, int y) {
  uint16_t c = radioLinkOK ? GOBLIN_GREEN : BLOOD_RED;
  tft.fillCircle(x, y, 6, c);
  tft.setTextColor(c);
  tft.setTextSize(1);
  tft.setCursor(x-18, y+10);
  tft.print(radioLinkOK ? F("LINK") : F("NO LK"));
}

void updateRGBStatus() {
  static uint8_t breath = 0;
  static int8_t dir = 5;
  breath += dir;
  if (breath > 200 || breath < 10) dir = -dir;
  switch (currentState) {
    case STATE_MENU:      leds[0] = CRGB(0, breath, 0);        break;
    case STATE_NFC:       leds[0] = CRGB(0, breath, breath);   break;
    case STATE_SUBGHZ:    leds[0] = CRGB(breath, breath/2, 0); break;
    case STATE_NRF24:     leds[0] = CRGB(0, breath, 0);        break;
    case STATE_IR:        leds[0] = CRGB(breath, 0, 0);        break;
    case STATE_WIFI:      leds[0] = CRGB(breath/2, 0, breath); break;
    case STATE_BLUETOOTH: leds[0] = CRGB(breath/2, 0, breath); break;
    default: break;
  }
  if (!radioLinkOK) leds[0] = CRGB(breath, 0, 0); // override: red if link down
  FastLED.show();
}
