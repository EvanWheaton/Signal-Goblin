# Signal Goblin Pinout and Wiring

This document details the pin assignments for the STM32WB55UG microcontroller and its connections to the various peripheral modules used in the Signal Goblin device.

## STM32WB55UG Pin Assignments

| Module           | Pin Function | STM32WB55UG Pin | Notes                                       |
| :--------------- | :----------- | :-------------- | :------------------------------------------ |
| **SPI1**         | SCK          | PA5             | Shared for CC1101, SD Card, Display         |
|                  | MISO         | PA6             |                                             |
|                  | MOSI         | PA7             |                                             |
| **CC1101**       | CS           | PB0             | Chip Select for CC1101 RF module            |
|                  | GDO0         | PB4             | General Digital Output 0 (Interrupt)        |
| **SD Card**      | CS           | PC13            | Chip Select for SD Card                     |
| **Display**      | CS           | PB1             | Chip Select for Display (if SPI)            |
|                  | DC           | PB10            | Data/Command for Display (if SPI)           |
|                  | RST          | PB11            | Reset for Display                           |
| **I2C1**         | SCL          | PB8             | Shared for PN532, SSD1306                   |
|                  | SDA          | PB9             |                                             |
| **PN532**        | IRQ          | PB5             | Interrupt Request from PN532                |
|                  | RST          | PB6             | Reset for PN532                             |
| **Buttons**      | UP           | PC0             | Active Low, Internal Pull-up                |
|                  | DOWN         | PC1             | Active Low, Internal Pull-up                |
|                  | OK           | PC2             | Active Low, Internal Pull-up                |
|                  | BACK         | PC3             | Active Low, Internal Pull-up                |
| **Buzzer**       | PWM Output   | PB2             | Connected to TIM2_CH2 for PWM generation    |
| **IR**           | TX           | PA1             | Infrared Transmitter                        |
|                  | RX           | PA0             | Infrared Receiver                           |
| **Battery Chg.** | Status       | PC4             | Charging Status Indicator (e.g., CHG/STAT)  |

## Wiring Diagrams

Detailed wiring diagrams illustrating the connections between the STM32WB55UG and each peripheral module will be provided here. These diagrams will include power, ground, and data lines for each component.

*   **Overall System Wiring Diagram**
*   **Display Module Wiring**
*   **RFID/NFC (PN532) Wiring**
*   **RF Transceiver (CC1101) Wiring**
*   **SD Card Breakout Wiring**
*   **Buttons and Buzzer Wiring**
*   **IR Module Wiring**
*   **Battery Charging Module Wiring**
