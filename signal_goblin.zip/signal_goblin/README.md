# Signal Goblin Firmware

## Project Overview

Signal Goblin is a pen-testing device inspired by Flipper Zero, designed around the STM32WB55UG microcontroller. It integrates various modules for RFID/NFC, RF communication, IR, and a user-friendly interface with a display and physical buttons. The firmware aims to be robust, modular, and easy to extend, with a focus on clear code structure and comprehensive documentation.

## Hardware Components

- **Microcontroller:** STM32WB55UG
- **Display:** 3.5" TFT OLED or SSD1306 (I2C/SPI)
- **RFID/NFC:** PN532 (I2C/SPI)
- **RF Transceiver:** CC1101 (SPI)
- **User Interface:** Up, Down, OK, Back buttons, Buzzer
- **Storage:** SD Card Breakout Board (SPI)
- **Power:** USB Type-C Battery Charging Module

## Firmware Architecture

The firmware is structured into several key modules, each responsible for a specific set of functionalities. This modular approach enhances maintainability, reusability, and testability.

### Directory Structure

```
signal_goblin/
├── src/
│   ├── core/               # MCU initialization, HAL configuration, system clock, GPIO
│   ├── modules/            # Drivers for PN532, CC1101, SD Card, IR, Buzzer, Battery Charger
│   ├── display/            # Display driver (SSD1306/TFT), graphics primitives
│   ├── animations/         # Goblin animations for different menus/modes
│   └── main.c              # Main application logic, super loop, task scheduler
├── lib/                    # External libraries (e.g., FreeRTOS, FatFs, specific sensor libraries)
├── docs/                   # Project documentation, pinouts, wiring diagrams, datasheets
├── inc/                    # Header files for all modules
└── README.md               # Project overview, build instructions, usage guide
```

## Module Plan

1.  **Core Firmware (`src/core`):**
    *   STM32CubeMX project setup for STM32WB55UG.
    *   System Clock Configuration.
    *   GPIO Initialization for all peripherals.
    *   SPI, I2C, UART (for debugging) peripheral initialization.
    *   Interrupt handling for buttons and external events.

2.  **Display Driver (`src/display`):**
    *   Initialization and control for selected display (SSD1306 or TFT).
    *   Basic graphics primitives (points, lines, rectangles, text).
    *   Buffering and display update mechanisms.

3.  **Animations (`src/animations`):**
    *   Storage and rendering logic for goblin animations.
    *   Animations for RF, RFID, IR, and other menu states.

4.  **RFID/NFC Module (`src/modules/pn532`):**
    *   PN532 driver for RFID/NFC read/write operations.
    *   Support for various card types (e.g., MiFare Classic, ISO14443A/B).

5.  **RF Module (`src/modules/cc1101`):**
    *   CC1101 driver for sub-GHz communication.
    *   Packet sending and receiving functionalities.
    *   Frequency hopping and modulation schemes.

6.  **IR Module (`src/modules/ir`):**
    *   Infrared signal generation (TX) and decoding (RX).
    *   Support for common IR protocols.

7.  **Buzzer Module (`src/modules/buzzer`):**
    *   PWM control for tone generation.
    *   Feedback for user interactions.

8.  **Button Module (`src/modules/buttons`):**
    *   GPIO input handling for Up, Down, OK, Back buttons.
    *   Debouncing logic.
    *   Event generation for menu navigation.

9.  **SD Card Module (`src/modules/sdcard`):**
    *   FatFs integration for file system access.
    *   Read/write operations for configuration, logs, and captured data.

10. **Battery Charging Module (`src/modules/charger`):**
    *   Monitoring of battery charging status.
    *   Integration with power management features of STM32WB55.

## Pinout and Wiring

Detailed pinout information can be found in [PINOUT.md](docs/PINOUT.md).

For visual guidance, refer to the wiring diagrams located in the `docs/` directory. These diagrams illustrate the connections between the STM32WB55UG and all peripheral modules.

## Development Environment

- **IDE:** STM32CubeIDE (recommended)
- **Toolchain:** GCC ARM Embedded
- **Debugging:** ST-Link/V2 or ST-Link/V3

## Build Instructions

(To be added)

## Usage Guide

(To be added)

## Contributing

(To be added)

## License

(To be added)
