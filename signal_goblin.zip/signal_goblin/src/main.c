#include "main.h"
#include <stdio.h>

/* Function Prototypes */
extern void Core_Init(void);
extern void SSD1306_Init(void);
extern void SSD1306_Clear(void);
extern void SSD1306_UpdateScreen(void);
extern void Goblin_Animate(uint8_t type, uint8_t frame);
extern void PN532_Init(void);
extern void CC1101_Init(void);
extern void Buzzer_Beep(uint16_t freq, uint16_t duration_ms);

/* Menu State */
typedef enum {
    MENU_MAIN,
    MENU_RF,
    MENU_RFID,
    MENU_IR,
    MENU_SETTINGS
} MenuState;

MenuState current_state = MENU_MAIN;
int menu_index = 0;
const char* menu_items[] = {"Sub-GHz RF", "RFID/NFC", "Infrared", "Settings"};
#define MENU_COUNT 4

void Display_Menu(void) {
    SSD1306_Clear();
    // Draw Title
    // SSD1306_DrawString(0, 0, "SIGNAL GOBLIN", 1);
    
    for (int i = 0; i < MENU_COUNT; i++) {
        if (i == menu_index) {
            // SSD1306_DrawString(0, 16 + i*10, "> ", 1);
        }
        // SSD1306_DrawString(10, 16 + i*10, menu_items[i], 1);
    }
    
    // Animate Goblin based on selection
    Goblin_Animate(menu_index, 0);
    SSD1306_UpdateScreen();
}

void Handle_Buttons(void) {
    if (HAL_GPIO_ReadPin(BTN_UP_PORT, BTN_UP_PIN) == GPIO_PIN_RESET) {
        menu_index = (menu_index - 1 + MENU_COUNT) % MENU_COUNT;
        Buzzer_Beep(1000, 50);
        HAL_Delay(200);
    }
    if (HAL_GPIO_ReadPin(BTN_DOWN_PORT, BTN_DOWN_PIN) == GPIO_PIN_RESET) {
        menu_index = (menu_index + 1) % MENU_COUNT;
        Buzzer_Beep(1000, 50);
        HAL_Delay(200);
    }
    if (HAL_GPIO_ReadPin(BTN_OK_PORT, BTN_OK_PIN) == GPIO_PIN_RESET) {
        Buzzer_Beep(2000, 100);
        // Enter Sub-menu logic
        HAL_Delay(200);
    }
    if (HAL_GPIO_ReadPin(BTN_BACK_PORT, BTN_BACK_PIN) == GPIO_PIN_RESET) {
        Buzzer_Beep(500, 100);
        // Back logic
        HAL_Delay(200);
    }
}

int main(void) {
    Core_Init();
    SSD1306_Init();
    PN532_Init();
    CC1101_Init();
    
    Buzzer_Beep(1500, 200);
    
    while (1) {
        Handle_Buttons();
        Display_Menu();
        HAL_Delay(50);
    }
}
