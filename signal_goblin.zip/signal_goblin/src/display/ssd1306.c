#include "main.h"
#include <string.h>

#define SSD1306_I2C_ADDR        0x78
#define SSD1306_WIDTH           128
#define SSD1306_HEIGHT          64

static uint8_t SSD1306_Buffer[SSD1306_WIDTH * SSD1306_HEIGHT / 8];

void SSD1306_WriteCommand(uint8_t cmd) {
    HAL_I2C_Mem_Write(&hi2c1, SSD1306_I2C_ADDR, 0x00, 1, &cmd, 1, 10);
}

void SSD1306_Init(void) {
    HAL_Delay(100);
    SSD1306_WriteCommand(0xAE); // Display Off
    SSD1306_WriteCommand(0x20); // Set Memory Addressing Mode
    SSD1306_WriteCommand(0x10); // Page Addressing Mode
    SSD1306_WriteCommand(0xB0); // Set Page Start Address for Page Addressing Mode
    SSD1306_WriteCommand(0xC8); // Set COM Output Scan Direction
    SSD1306_WriteCommand(0x00); // Set Low Column Address
    SSD1306_WriteCommand(0x10); // Set High Column Address
    SSD1306_WriteCommand(0x40); // Set Start Line Address
    SSD1306_WriteCommand(0x81); // Set Contrast Control
    SSD1306_WriteCommand(0xFF);
    SSD1306_WriteCommand(0xA1); // Set Segment Re-map
    SSD1306_WriteCommand(0xA6); // Set Normal Display
    SSD1306_WriteCommand(0xA8); // Set Multiplex Ratio
    SSD1306_WriteCommand(0x3F);
    SSD1306_WriteCommand(0xA4); // Entire Display On
    SSD1306_WriteCommand(0xD3); // Set Display Offset
    SSD1306_WriteCommand(0x00);
    SSD1306_WriteCommand(0xD5); // Set Display Clock Divide Ratio/Oscillator Frequency
    SSD1306_WriteCommand(0xF0);
    SSD1306_WriteCommand(0xD9); // Set Pre-charge Period
    SSD1306_WriteCommand(0x22);
    SSD1306_WriteCommand(0xDA); // Set COM Pins Hardware Configuration
    SSD1306_WriteCommand(0x12);
    SSD1306_WriteCommand(0xDB); // Set VCOMH Deselect Level
    SSD1306_WriteCommand(0x20);
    SSD1306_WriteCommand(0x8D); // Set Charge Pump
    SSD1306_WriteCommand(0x14);
    SSD1306_WriteCommand(0xAF); // Display On
}

void SSD1306_UpdateScreen(void) {
    for (uint8_t i = 0; i < 8; i++) {
        SSD1306_WriteCommand(0xB0 + i);
        SSD1306_WriteCommand(0x00);
        SSD1306_WriteCommand(0x10);
        HAL_I2C_Mem_Write(&hi2c1, SSD1306_I2C_ADDR, 0x40, 1, &SSD1306_Buffer[SSD1306_WIDTH * i], SSD1306_WIDTH, 100);
    }
}

void SSD1306_Clear(void) {
    memset(SSD1306_Buffer, 0, sizeof(SSD1306_Buffer));
}

void SSD1306_DrawPixel(uint8_t x, uint8_t y, uint8_t color) {
    if (x >= SSD1306_WIDTH || y >= SSD1306_HEIGHT) return;
    if (color) SSD1306_Buffer[x + (y / 8) * SSD1306_WIDTH] |= (1 << (y % 8));
    else SSD1306_Buffer[x + (y / 8) * SSD1306_WIDTH] &= ~(1 << (y % 8));
}

void SSD1306_DrawBitmap(uint8_t x, uint8_t y, const uint8_t* bitmap, uint8_t w, uint8_t h) {
    for (uint8_t j = 0; j < h; j++) {
        for (uint8_t i = 0; i < w; i++) {
            if (bitmap[i + (j / 8) * w] & (1 << (j % 8))) {
                SSD1306_DrawPixel(x + i, y + j, 1);
            }
        }
    }
}
