#include "main.h"

/* Buzzer Functions */
void Buzzer_Beep(uint16_t freq, uint16_t duration_ms) {
    if (freq == 0) {
        HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_2);
        return;
    }
    uint32_t period = 1000000 / freq;
    __HAL_TIM_SET_AUTORELOAD(&htim2, period - 1);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, period / 2);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
    HAL_Delay(duration_ms);
    HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_2);
}

/* IR Functions (Simple PWM-based TX) */
void IR_SendRaw(uint32_t* pulses, uint16_t len) {
    for (int i = 0; i < len; i++) {
        if (i % 2 == 0) {
            // Carrier ON (38kHz)
            Buzzer_Beep(38000, pulses[i] / 1000);
        } else {
            // Carrier OFF
            HAL_Delay(pulses[i] / 1000);
        }
    }
}

/* SD Card Placeholder (Requires FatFs integration) */
void SD_Init(void) {
    // Initialization logic for SD card via SPI
    // This would typically involve FatFs f_mount
}
