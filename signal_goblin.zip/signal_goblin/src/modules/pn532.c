#include "main.h"

#define PN532_I2C_ADDR          0x48
#define PN532_COMMAND_GETFIRMWAREVERSION 0x02
#define PN532_COMMAND_SAMCONFIGURATION   0x14
#define PN532_COMMAND_INLISTPASSIVETARGET 0x4A

void PN532_WriteCommand(uint8_t* cmd, uint8_t len) {
    uint8_t packet[len + 8];
    packet[0] = 0x00;
    packet[1] = 0x00;
    packet[2] = 0xFF;
    packet[3] = len + 1;
    packet[4] = ~(len + 1) + 1;
    packet[5] = 0xD4;
    for (int i = 0; i < len; i++) packet[6 + i] = cmd[i];
    uint8_t sum = 0xD4;
    for (int i = 0; i < len; i++) sum += cmd[i];
    packet[6 + len] = ~sum + 1;
    packet[7 + len] = 0x00;
    HAL_I2C_Master_Transmit(&hi2c1, PN532_I2C_ADDR, packet, len + 8, 100);
}

void PN532_Init(void) {
    HAL_GPIO_WritePin(PN532_RST_PORT, PN532_RST_PIN, GPIO_PIN_RESET);
    HAL_Delay(10);
    HAL_GPIO_WritePin(PN532_RST_PORT, PN532_RST_PIN, GPIO_PIN_SET);
    HAL_Delay(10);
    uint8_t sam_cmd[] = {PN532_COMMAND_SAMCONFIGURATION, 0x01, 0x14, 0x01};
    PN532_WriteCommand(sam_cmd, 4);
}

uint8_t PN532_ReadPassiveTarget(uint8_t* uid) {
    uint8_t cmd[] = {PN532_COMMAND_INLISTPASSIVETARGET, 0x01, 0x00};
    PN532_WriteCommand(cmd, 3);
    HAL_Delay(100);
    uint8_t response[20];
    HAL_I2C_Master_Receive(&hi2c1, PN532_I2C_ADDR, response, 20, 100);
    if (response[12] == 0x00) return 0; // No target found
    uint8_t uid_len = response[17];
    for (int i = 0; i < uid_len; i++) uid[i] = response[18 + i];
    return uid_len;
}
