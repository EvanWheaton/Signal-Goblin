#include "main.h"

/* Battery Monitoring and Power Management */
float Battery_GetVoltage(void) {
    // ADC configuration for battery monitoring
    // Typically connected to a voltage divider on PC4
    uint32_t adc_val = 0;
    // HAL_ADC_Start(&hadc1);
    // HAL_ADC_PollForConversion(&hadc1, 10);
    // adc_val = HAL_ADC_GetValue(&hadc1);
    // HAL_ADC_Stop(&hadc1);
    
    // Convert ADC value to voltage (assuming 3.3V Vref and 1:1 divider)
    return (float)adc_val * 3.3f / 4095.0f * 2.0f;
}

uint8_t Battery_IsCharging(void) {
    // Check charging status pin from C-type module
    // Assuming active low status pin on PC4
    return (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_4) == GPIO_PIN_RESET);
}

void Power_EnterSleep(void) {
    // Enter low power mode
    HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);
}

void Power_EnterDeepSleep(void) {
    // Enter STOP mode for maximum power saving
    HAL_PWR_EnterSTOPMode(PWR_LOWPOWERREGULATOR_ON, PWR_STOPENTRY_WFI);
}
