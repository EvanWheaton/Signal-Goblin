#ifndef __PN532_H
#define __PN532_H

#include <stdint.h>

void PN532_Init(void);
uint8_t PN532_ReadPassiveTarget(uint8_t* uid);

#endif /* __PN532_H */
