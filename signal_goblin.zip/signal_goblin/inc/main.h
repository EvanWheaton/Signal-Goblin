#ifndef __MAIN_H
#define __MAIN_H

#include "stm32wbxx_hal.h"

/* Pin Definitions */
#define BTN_UP_PIN          GPIO_PIN_0
#define BTN_UP_PORT         GPIOC
#define BTN_DOWN_PIN        GPIO_PIN_1
#define BTN_DOWN_PORT       GPIOC
#define BTN_OK_PIN          GPIO_PIN_2
#define BTN_OK_PORT         GPIOC
#define BTN_BACK_PIN        GPIO_PIN_3
#define BTN_BACK_PORT       GPIOC

#define BUZZER_PIN          GPIO_PIN_2
#define BUZZER_PORT         GPIOB

#define DISP_CS_PIN         GPIO_PIN_1
#define DISP_CS_PORT        GPIOB
#define DISP_DC_PIN         GPIO_PIN_10
#define DISP_DC_PORT        GPIOB
#define DISP_RST_PIN        GPIO_PIN_11
#define DISP_RST_PORT       GPIOB

#define CC1101_CS_PIN       GPIO_PIN_0
#define CC1101_CS_PORT      GPIOB
#define CC1101_GDO0_PIN     GPIO_PIN_4
#define CC1101_GDO0_PORT    GPIOB

#define SDCARD_CS_PIN       GPIO_PIN_13
#define SDCARD_CS_PORT      GPIOC

#define PN532_IRQ_PIN       GPIO_PIN_5
#define PN532_IRQ_PORT      GPIOB
#define PN532_RST_PIN       GPIO_PIN_6
#define PN532_RST_PORT      GPIOB

/* Peripheral Handles */
extern SPI_HandleTypeDef hspi1;
extern I2C_HandleTypeDef hi2c1;
extern UART_HandleTypeDef huart1;
extern TIM_HandleTypeDef htim2;

void Error_Handler(void);

#endif /* __MAIN_H */
