#ifndef __CC1101_H
#define __CC1101_H

#include <stdint.h>

void CC1101_Init(void);
void CC1101_SendPacket(uint8_t* data, uint8_t len);

#endif /* __CC1101_H */
