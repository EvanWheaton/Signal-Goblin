#ifndef __CORE_H
#define __CORE_H

#include "stm32wbxx_hal.h"

void Core_Init(void);
void Error_Handler(void);

#endif /* __CORE_H */
